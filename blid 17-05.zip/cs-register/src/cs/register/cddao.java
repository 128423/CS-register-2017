/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs.register;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author luis
 */
public class cddao implements abrirefechar{
    
     private List<partida> list1  =  new ArrayList<>();
     private  partida p ;
             
    @Override
    public void salvaresair() {
         try     {
             FileWriter arq =  new FileWriter("save.txt");
             PrintWriter gravaarq = new PrintWriter(arq);
             for(partida c :list1 ) {
                gravaarq. printf("%d %d %d %d %d %d %n",c.getKill(),c.getDeath(),c.getAssist(),c.getWld(),c.getSocore(),c.getRank());
             } 
             gravaarq.print("-99");
             arq.close();
             System.exit(0);
         } catch (IOException ex) {
             Logger.getLogger(cddao.class.getName()).log(Level.SEVERE, null, ex);
         } 
    }
    
    public void addlist ( partida p  ){
        this.list1.add(p);
    }

    public List<partida> getList1() {
        return list1;
    }

    public void setList1(List<partida> list1) {
        this.list1 = list1;
    }

     @Override
    public void lerd() {
         try {
             FileReader arq = new FileReader("save.txt");
             BufferedReader learq = new  BufferedReader(arq);
             int linha = learq.read();
             
             while (linha != -99){
                 
             p = new partida();
             p.setKill(linha);
             linha = learq.read();
             p.setDeath(linha);
             linha = learq.read();
             p.setAssist(linha);
             linha = learq.read();
             p.setWld(linha);
             linha = learq.read();
             p.setSocore(linha);
             linha = learq.read();
             p.setRank(linha);
             this.addlist(p); 
             linha = learq.read();
             }
       
         } catch (FileNotFoundException ex) {
             Logger.getLogger(cddao.class.getName()).log(Level.SEVERE, null, ex);
         } catch (IOException ex) {
             Logger.getLogger(cddao.class.getName()).log(Level.SEVERE, null, ex);
         }
        
    }
    
}
