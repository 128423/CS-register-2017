/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs.register;

/**
 *
 * @author luis
 */
public class partida  {
    private Integer  kill ;
    private Integer death ;
    private Integer assist;
    private Integer wld;
    private Integer socore;
    private Integer rank;
    
    
   public partida() {
       
    }

    public partida(Integer kill, Integer death, Integer assist, Integer wld, Integer socore, Integer rank) {
        this.kill = kill;
        this.death = death;
        this.assist = assist;
        this.wld = wld;
        this.socore = socore;
        this.rank = rank;
    }

            
            
            
    /**
     * @return the kill
     */
    public Integer getKill() {
        return kill;
    }

    /**
     * @param kill the kill to set
     */
    public void setKill(Integer kill) {
        this.kill = kill;
    }

    /**
     * @return the death
     */
    public Integer getDeath() {
        return death;
    }

    /**
     * @param death the death to set
     */
    public void setDeath(Integer death) {
        this.death = death;
    }

    /**
     * @return the assist
     */
    public Integer getAssist() {
        return assist;
    }

    /**
     * @param assist the assist to set
     */
    public void setAssist(Integer assist) {
        this.assist = assist;
    }

    /**
     * @return the wld
     */
    public Integer getWld() {
        return wld;
    }

    /**
     * @param wld the wld to set
     */
    public void setWld(Integer wld) {
        this.wld = wld;
    }

    /**
     * @return the socore
     */
    public Integer getSocore() {
        return socore;
    }

    /**
     * @param socore the socore to set
     */
    public void setSocore(Integer socore) {
        this.socore = socore;
    }

    /**
     * @return the rank
     */
    public Integer getRank() {
        return rank;
    }

    /**
     * @param rank the rank to set
     */
    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return "partida{" + "kill=" + kill + ", death=" + death + ", assist=" + assist + ", wld=" + wld + ", socore=" + socore + ", rank=" + rank + '}';
    }
    
}
