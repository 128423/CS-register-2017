
import cs.register.cddao;
import cs.register.partida;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luis
 */
public class test {

    /**
     * @param args the command line arguments
     */

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        partida p = new partida(1,3,5,2,7,1);
        cddao  d = new cddao();
        d.addlist(p);
        p = new partida(1,3,5,2,7,1);
        d.addlist(p);
        System.out.println("test.main()");
     //  d.salvaresair();
        d.lerd();
        d.getList1().forEach((c) -> {
            System.out.println(c);
        });
        
        
    }
    
}
