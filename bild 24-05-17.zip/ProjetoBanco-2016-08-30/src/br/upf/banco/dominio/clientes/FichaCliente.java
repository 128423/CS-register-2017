/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.upf.banco.dominio.clientes;

import java.util.Date;

/**
 *
 * @author jaqson
 */
public class FichaCliente {
    // Atributos
    private String nome;
    public final Date dataNascimento;
    private transient int idade;
    private Cidade mora;
    private ReferenciaComercial referencia;
    
    public FichaCliente(Date nascimento){
        dataNascimento = nascimento;
    }
    
    public void setNome(String nome){
       this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public Date getDataNascimento(){
        return dataNascimento;
    }
    
    /* não é possível!!! o atributo é final!!!!!    
    public void setDataNascimento(Date dia){
    dataNascimento = dia;
    }
    */
    
    public int getIdade(){
        long dif = new Date().getTime() - dataNascimento.getTime();
        idade = (int) (dif / 1000 / 60 / 60 / 24 / 365);
        return idade;
    }

    public Cidade getMora() {
        return mora;
    }

    public void setMora(Cidade mora) {
        this.mora = mora;
    }

    public ReferenciaComercial getReferencia() {
        return referencia;
    }

    public void setReferencia(ReferenciaComercial referencia) {
        this.referencia = referencia;
    }
    
    
}
