/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.upf.banco.dominio.clientes;

/**
 *
 * @author jaqson
 */
public class ReferenciaComercial {
    private String nomeDaLoja;
    private String endereco;
    private String fone;

    public ReferenciaComercial(String nomeDaLoja, String endereco, String fone) {
        this.nomeDaLoja = nomeDaLoja;
        this.endereco = endereco;
        this.fone = fone;
    }

    public ReferenciaComercial() {
    }

    
    public String getNomeDaLoja() {
        return nomeDaLoja;
    }

    public void setNomeDaLoja(String nomeDaLoja) {
        this.nomeDaLoja = nomeDaLoja;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
    
}
