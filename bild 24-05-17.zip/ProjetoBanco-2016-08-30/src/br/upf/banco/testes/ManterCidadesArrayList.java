/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.upf.banco.testes;

import br.upf.banco.dominio.clientes.Cidade;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author jaqson
 */
public class ManterCidadesArrayList {

    private static List<Cidade> lista = new ArrayList();
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Programa para ler e listar cidades em um vetor
        while (true) {
            System.out.println("-------------------");
            System.out.println(" i = Incluir");
            System.out.println(" a = Alterar");
            System.out.println(" e = Excluir");
            System.out.println(" c = Consultar");
            System.out.println(" l = Listar");
            System.out.println(" s = Sair");
            System.out.print("Opção: ");
            char lido = new Scanner(System.in).next().charAt(0);
            System.out.println("-------------------");
            switch (lido) {
                case 'i': {
                    incluir();
                    break;
                }
                case 'l': {
                    listar();
                    break;
                }
                case 'c': {
                    consultar();
                    break;
                }
                case 'e': {
                    excluir();
                    break;
                }
                case 's': {
                    System.exit(0);
                    break;
                }
            }
        }

    }

    private static void incluir() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Scanner ler = new Scanner(System.in);
        Cidade c = new Cidade();
        System.out.print("Informe o nome: ");
        c.setNome(ler.nextLine());
        System.out.print("Informe o estado: ");
        c.setEstado(ler.nextLine());
        lista.add(c);
        //lista.add(new Date());
    }

    private static void listar() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Listagem das cidades...");
        for(Cidade o : lista)
            System.out.println(o);
        System.out.println("Pressione enter para continuar.");
        new Scanner(System.in).nextLine();
    }

    private static void consultar() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.print("Nome da cidade a localizar: "); 
        String lido = new Scanner(System.in).nextLine();
        Cidade busca = new Cidade(lido, "RS");
        if (lista.contains(busca)){
            System.out.println("Encontrado na posição "+lista.indexOf(busca));
        }else{
            System.out.println("Não encontrado...");
        }
    }

    private static void excluir() {
        System.out.print("Nome da cidade a excluir: "); 
        String lido = new Scanner(System.in).nextLine();
        Cidade busca = new Cidade(lido, "RS");
        if (lista.remove(busca)){
            System.out.println("Removido ");
        }else{
            System.out.println("Não encontrado...");
        }
    }


    
}
