/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.upf.banco.testes;

import br.upf.banco.dominio.clientes.Cidade;
import java.util.Scanner;

/**
 *
 * @author jaqson
 */
public class ManterCidadesEmVetor {

    private static Cidade[] lista = new Cidade[5];
    private static int cont = 0;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Programa para ler e listar cidades em um vetor
        while (true) {
            System.out.println("-------------------");
            System.out.println(" i = Incluir");
            System.out.println(" l = Listar");
            System.out.println(" s = Sair");
            System.out.print("Opção: ");
            char lido = new Scanner(System.in).nextLine().charAt(0);
            System.out.println("-------------------");
            switch (lido) {
                case 'i': {
                    incluir();
                    break;
                }
                case 'l': {
                    listar();
                    break;
                }
                case 's': {
                    System.exit(0);
                    break;
                }
            }
        }

    }

    private static void incluir() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Scanner ler = new Scanner(System.in);
        Cidade c = new Cidade();
        System.out.print("Informe o nome: ");
        c.setNome(ler.nextLine());
        System.out.print("Informe o estado: ");
        c.setEstado(ler.nextLine());
        lista[cont++] = c;
    }

    private static void listar() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Listagem das cidades...");
        for(int i=0; i < cont; i++)
            System.out.println(lista[i]);
        System.out.println("Pressione enter para continuar.");
        new Scanner(System.in).nextLine();
    }

}
