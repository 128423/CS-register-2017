/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.upf.banco.testes;

import br.upf.banco.dominio.clientes.Cidade;
import br.upf.banco.dominio.clientes.FichaCliente;
import br.upf.banco.dominio.clientes.ReferenciaComercial;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author jaqson
 */
public class TestesFichaCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Instanciar um objeto da classe FichaCliente
        try {
            FichaCliente f1 = new FichaCliente(new SimpleDateFormat().parse("10/05/2000 00:00"));
            f1.setNome("Maria");
            //f1.dataNascimento = new Date();
            Cidade c1 = new Cidade();
            c1.setNome("Passo Fundo");
            Cidade c2 = new Cidade("Soledade", "RS");
            // fazer a associação dos objetos para dizer que maria mora em Soledade
            f1.setMora(c2);
            
            // Instanciar referencias
            ReferenciaComercial rc1 = new ReferenciaComercial("Loja x", "Rua x", "12354123");
            
            // fazer a agregação
            f1.setReferencia(rc1);
            
            
            
            FichaCliente f2 = new FichaCliente(new Date());
            f2.setNome("José");
            mostrarFicha(f1);
            mostrarFicha(f2);
        }catch (Exception e){
            System.out.println("Ocorreu um erro. A mensagem é "+e.getMessage());
        } 
        
    }

    private static void mostrarFicha(FichaCliente f1) {
        // Agora vamos mostrar os dados de cada ficha...
        System.out.println("DADOS DA FICHA");
        System.out.println("Nome: "+f1.getNome());
        System.out.println("Nascimento: "+
                new SimpleDateFormat().format(f1.getDataNascimento()));
        System.out.println("Idade: "+f1.getIdade());
        System.out.println("----------------------");
    }
    
}
