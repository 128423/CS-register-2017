
import cs.register.cddao;
import cs.register.geraGrafico;
import cs.register.partida;
import org.jfree.ui.RefineryUtilities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luis
 */
public class test {

    /**
     * @param args the command line arguments
     */

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        cddao  d = new cddao();
        partida p = new partida(1,3,5,2,7,1);
        d.addlist(p);
        p = new partida(2,3,1,2,6,3);
        d.addlist(p);
        p = new partida(3,4,3,9,3,4);
        d.addlist(p);
        System.out.println("test.main()");
        //  d.salvaresair();
      //  d.lerd();
       for ( partida x : d.getList1()) {
            System.out.println(x);
          }
                  
        geraGrafico g = new geraGrafico("kda",1, d.getList1());
        g.pack();
        RefineryUtilities.centerFrameOnScreen( g );  
        g.setVisible(true);
  
    }
    
}
